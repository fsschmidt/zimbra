## Zimbra Scripts
--------

### Uso:
```bash
zmprov -l gaa domain.com > /tmp/users
./zmdelimagessignature.sh /tmp/users
```