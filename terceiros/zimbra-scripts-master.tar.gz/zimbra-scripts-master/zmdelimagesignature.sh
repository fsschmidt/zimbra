#!/bin/bash
# Desenvolvido por: Julio Saraiva - julio@bktech.com.br
# BK Tecnologia da Informação

function getSignature() {
    for account in $(cat $getAccount)
        do
            DIR_USER="${DIR}/${account}"
            if [ ! -d "$DIR_USER" ]; then
                mkdir $DIR_USER
            fi
            zmprov gsig ${account} zimbraPrefMailSignatureHTML | grep -A 1 "Modelo de Assinatura" > "$DIR_USER/${account}_SignatureHTML"
            if [ -s "$DIR_USER/${account}_SignatureHTML" ]; then
                sed -i 's/^zimbraPrefMailSignatureHTML: //;/^# name/d' "$DIR_USER/${account}_SignatureHTML"
                if [ -f "$DIR_USER/${account}_SignatureHTML" ] && [ -s "$DIR_USER/${account}_SignatureHTML" ]; then
                    sed -i.bak "s/${OLD_URL}/${NEW_URL}/g" "$DIR_USER/${account}_SignatureHTML"
                    SIGNATURE="$(cat "$DIR_USER/${account}_SignatureHTML")"
                fi
                echo "Alterando a assinatura da conta ${account}..."
                zmprov ma $account zimbraPrefMailSignatureHTML "${SIGNATURE}"
            fi
        done
}


# Defina aqui a nova URL - Adicione contra-barra para cada barra para melhor interpretação do sed
NEW_URL=""

# Escolha a URL a ser substituída - Adicione contra-barra para cada barra para melhor interpretação do sed
OLD_URL='<img src=\"http:\/\/mailing.cultura.gov.br\/wp-content\/uploads\/sites\/11\/2017\/10\/assinatura-minc.png\" data-mce-src=\"http:\/\/mailing.cultura.gov.br\/wp-content\/uploads\/sites\/11\/2017\/10\/assinatura-minc.png\">'

# Obtém o nome do arquivo que contém a lista de usuários
getAccount=$1

# Diretorio onde serão salvas as assinaturas atual para alteração.
DIR="/tmp/signature_replace"

# Variável para alterar uma parte do código HTML
HTML_EDITOR="font-size: 9pt; color: rgb(0, 0, 0);"

# Verifica se o diretório para armazenar as assinaturas existe. Se não existir
# será criado.
if [ ! -d "$DIR" ]; then
    mkdir "$DIR"
fi

# Chama a função getSignature
getSignature
