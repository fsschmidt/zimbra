#!/bin/bash
#
###   zmreplacesignature - version 1.3 - Mantido por BKTECH <http://www.bktech.com.br>
###   Copyright (C) 2017  Julio Saraiva <julio@bktech.com.br>
###   Date: 7/11/2017
# Release Notes:
# - Alteração para obter o nome da variavel e modificar a assinatura de acordo com o nome dessa assinatura


function getSignature() {
    for account in $(cat $getAccount)
        do
            DIR_USER="${DIR}/${account}"
            if [ ! -d "$DIR_USER" ]; then
                mkdir $DIR_USER
            fi
            zmprov gsig "${account}" zimbraPrefMailSignatureHTML | egrep -m 1 -B 1 "${OLD_URL}" > "$DIR_USER/${account}_SignatureHTML"
            CHECK_SIGNAME=$(zmprov gsig "${account}" zimbraPrefMailSignatureHTML | egrep -m 1 -B1 "${OLD_URL}" | egrep "^# name" |awk -F"name " '{print $2}' | grep -v "^$")
            SIGNAME="$CHECK_SIGNAME"
            sed -i 's/^zimbraPrefMailSignatureHTML: //;/^# name/d' "$DIR_USER/${account}_SignatureHTML"
            if [ -f "$DIR_USER/${account}_SignatureHTML" ] && [ -s "$DIR_USER/${account}_SignatureHTML" ]; then
                sed -i.bak "s/${OLD_URL}/${NEW_URL}/g;s/${HTML_EDITOR}//g" "$DIR_USER/${account}_SignatureHTML"
                SIGNATURE="$(cat "$DIR_USER/${account}_SignatureHTML")"
            fi
			if [ ! -z "$SIGNATURE" ] && [ ! -z "$SIGNAME" ]; then
            	echo "Alterando a assinatura '"${SIGNAME}"' da conta ${account}..."
				zmprov msig $account "${SIGNAME}" zimbraPrefMailSignatureHTML "${SIGNATURE}"
			fi
        done
}


# Defina aqui a nova URL - Adicione contra-barra para cada barra para melhor interpretação do sed
NEW_URL="http:\/\/webmail.cultura.gov.br\/public\/signature\/assinatura-minc.png"
# Escolha a URL a ser substituída - Adicione contra-barra para cada barra para melhor interpretação do sed
#LD_URL="http:\/\/rouanet.cultura.gov.br\/wp-content\/uploads\/assinatura-zimbra\/assinatura-minc.png"
OLD_URL="http:\/\/mailing.cultura.gov.br\/wp-content\/uploads\/sites\/11\/2017\/10\/assinatura-minc.png"

# Obtém o nome do arquivo que contém a lista de usuários
getAccount=$1

# Diretorio onde serão salvas as assinaturas atual para alteração.
DIR="/tmp/signature_replace"

# Variável para alterar uma parte do código HTML
#HTML_EDITOR='<img src=\"http:\/\/www.cultura.gov.br\/documents\/10180\/0\/gera-futuro.png\" data-mce-src=\"http:\/\/www.cultura.gov.br\/documents\/10180\/0\/gera-futuro.png\">'
#HTML_EDITOR='<img src=\"http:\/\/www.cultura.gov.br\/documents\/10180\/0\/gera-futuro.png\">'

# Verifica se o diretório para armazenar as assinaturas existe. Se não existir
# será criado.
if [ ! -d "$DIR" ]; then
    mkdir "$DIR"
fi

# Nome Modelo da Assinatura
# SIGNAME='Modelo de Assinatura'

# Chama a função getSignature
getSignature
